### Hexlet tests and linter status:
[![Actions Status](https://github.com/coder108-gh/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/coder108-gh/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/2bdced7337f6c88aff2f/maintainability)](https://codeclimate.com/github/coder108-gh/python-project-49/maintainability)