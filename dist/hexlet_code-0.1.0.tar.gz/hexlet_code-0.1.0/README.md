### ASCIINEMA
## install and brain-even
[![asciicast](https://asciinema.org/a/H0uTHPSNUBrJT2oxeIFM4Gnr5.svg)](https://asciinema.org/a/H0uTHPSNUBrJT2oxeIFM4Gnr5)
## brain-calc
[![asciicast](https://asciinema.org/a/UrwCvQSKdqpTvWUu7y0VRFhj2.svg)](https://asciinema.org/a/UrwCvQSKdqpTvWUu7y0VRFhj2)
## brain-gcd
[![asciicast](https://asciinema.org/a/6b4YPq07INztxElClO8G1q6Gw.svg)](https://asciinema.org/a/6b4YPq07INztxElClO8G1q6Gw)
### Hexlet tests and linter status:
[![Actions Status](https://github.com/coder108-gh/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/coder108-gh/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/2bdced7337f6c88aff2f/maintainability)](https://codeclimate.com/github/coder108-gh/python-project-49/maintainability)
